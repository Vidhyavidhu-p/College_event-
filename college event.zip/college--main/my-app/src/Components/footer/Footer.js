import React from 'react'

function Footer() {
  return (
    <div class="footer-bottom">
    <p>&copy; 2024 College Event Management. All rights reserved.</p>
</div>

  )
}

export default Footer